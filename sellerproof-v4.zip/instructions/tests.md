1. health
2. Register
3. Copy a verification_code from a user table
4. Login
5. Refresh
6. Logout
7. Profile